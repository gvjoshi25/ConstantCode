package assignment.merchant.galaxy.guide.utils;

public enum Codes
{
	NO_IDEA, NO_INPUT, INVALID_ROMAN_STR, INVALID_INPUT, INVALID_ROMAN_CHAR, INCORRECT_LINE_TYPE, INVALID_FILE, PATH_MISSING
}